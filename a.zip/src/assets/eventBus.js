/**
 * Created by Administrator on 2017/5/18.
 */
import Vue from 'vue'
export default new Vue
